<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // Switch Example No. - 3
$ch='e';
switch($ch)
{
    case 'a': 
        echo "Vowel";
        break;
    case 'e': 
        echo "Vowel";
        break;
    case 'i': 
        echo "Vowel";
        break;
    case 'o': 
        echo "Vowel";
        break;
    case 'u': 
        echo "Vowel";
        break;
    case 'A': 
        echo "Vowel";
        break;
    case 'E': 
        echo "Vowel";
        break;
    case 'I': 
        echo "Vowel";
        break;
    case 'O': 
        echo "Vowel";
        break;
    case 'U': 
        echo "Vowel";
        break;
    default: 
        echo "Consonant";
}

    ?>
</body>
</html>