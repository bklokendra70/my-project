<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Example - 1
// The PHP strlen() function returns 
// the length of a string.
// echo strlen("Micro Solution");

// Example - 2 
// The PHP str_word_count() function 
// counts the number of words in a 
// string.
// echo str_word_count("MSoluticro ion");

// Example - 3
// The PHP strrev() function reverses a 
// string.
// echo strrev("Micro Solution");

// Example - 4
// The PHP strpos() function searches for a 
// specific text within a string. 
// If a match is found, the function 
// returns the character position of the 
// first match. If no match is found, 
// it will return FALSE.
// echo strpos("Micro Solution", "S");

// Example - 5
// The PHP str_replace() function replaces 
// some characters with some other 
// characters in a string.
// echo str_replace("Abhishek", "Micro Solution", "Hello Abhishek");

// Example - 6

// echo str_repeat("Micro Solution",5);
?>
</body>
</html>
